--19-CS-56
--19-CS-57
--19-CS-70
-- Table structure for table `hostel`
create TABLE hostel (
  Hostel_id int Primary key ,
  Hostel_name varchar(255) NOT NULL,
  current_no_of_rooms varchar(255) DEFAULT NULL,
  No_of_rooms varchar(255) DEFAULT NULL,
  No_of_students varchar(255) DEFAULT NULL
) 
--ALTER TABLE hostel
  --//Modify Hostel_id int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
  
INSERT INTO hostel (Hostel_id, Hostel_name, current_no_of_rooms, No_of_rooms, No_of_students)
VALUES
(1, 'A', NULL, '400', NULL),
(2, 'B', NULL, '400', NULL),
(3, 'C', NULL, '400', NULL),
(4, 'D', NULL, '400', NULL),
(5, 'E', NULL, '400', NULL),
(6, 'F', NULL, '400', NULL);

Select * from hostel;

-- Table structure for table `hostel_manager`
--

create TABLE hostel_manager (
  Hostel_man_id int Primary key,
  Username varchar(255) NOT NULL,
  Fname varchar(255) NOT NULL,
  Lname varchar(255) NOT NULL,
  Mob_no varchar(255) NOT NULL,
  Hostel_id int FOREIGN KEY  REFERENCES hostel(hostel_id),
  Pwd varchar(255) NOT NULL,
  Isadmin int DEFAULT 0
) 
--ALTER TABLE hostel_manager
  --alter Hostel_man_id int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

INSERT INTO hostel_manager (Hostel_man_id, Username, Fname, Lname, Mob_no, Hostel_id, Pwd, Isadmin)
VALUES
(10, 'zohaib', 'ali', 'ali', '76545432', 1, '123', 1),
(11, 'hamza', 'hassan', 'hassan', '76545432', 2, '123', 0),
(12, 'abc', 'raima', 'raima', '76545432', 1, '123', 0);

select * from  hostel_manager;

create TABLE message (
  msg_id int Primary key,
  sender_id varchar(255) DEFAULT NULL,
  receiver_id varchar(255) DEFAULT NULL,
  subject_h varchar(255) DEFAULT NULL,
  message varchar(255) DEFAULT NULL,
  msg_date varchar(255) DEFAULT NULL,
  msg_time varchar(255) DEFAULT NULL,
  Hostel_id int FOREIGN KEY  REFERENCES hostel(hostel_id)
) 
--ALTER TABLE message
  --alter msg_id int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

INSERT INTO message (msg_id, sender_id, receiver_id, hostel_id, subject_h, message, msg_date, msg_time) 
VALUES
(1, 'B160497CS', '3', 1, 'Ground Floor Request', 'sfdbfbdf', '2018-10-27', '09:14 PM'),
(2, '3', 'B160497CS', 1, 'DVDSG', 'DDSCSDV', '2018-10-27', '09:15PM'),
(3, '3', 'B160497CS', 1, 'wddwd', 'xssss', '2018-10-28', '09-16 PM'),
(4, 'B160498EE', '1', 3, 'ROOM NEAR TOILET', 'I would like to change my room as it is near toilet', '2018-10-27', '10:06 PM'),
(5, '1', 'B160498EE', 3, 'Room Near Toilet', 'cdsdgdfhdfh', '2018-10-27', '10:48 PM');

select * from message;

--
-- Table structure for table `room`
--

create TABLE room (
  Room_id int Primary key,
  Hostel_id int FOREIGN KEY  REFERENCES hostel(hostel_id),
  Room_No int NOT NULL,
  Allocated int DEFAULT 0
)



INSERT INTO room (Room_id, Hostel_id, Room_No, Allocated) 
VALUES
(1, 1, 45, 1),
(2, 2, 2, 1),
(3, 3, 3, 1),
(4, 4, 5, 1),
(5, 5, 6, 0),
(6, 6, 7, 0);


-- Table structure for table `student`
--

create TABLE student (
  Student_id varchar(255) Primary Key,
  Fname varchar(255) NOT NULL,
  Lname varchar(255) NOT NULL,
  Mob_no varchar(255) NOT NULL,
  Dept varchar(255) NOT NULL,
  Year_of_study varchar(255) NOT NULL,
  Pwd varchar(255) NOT NULL,
  Hostel_id int FOREIGN KEY  REFERENCES hostel(Hostel_id),
  Room_id int FOREIGN KEY  REFERENCES Room(room_id),
) 


INSERT INTO student (Student_id, Fname, Lname, Mob_no, Dept, Year_of_study, Pwd, Hostel_id, Room_id)
VALUES
('1205', 'umair', 'khan', '123456789', 'CP', '2012', '$2y$10$BHCNqeVQPDD6xzduYR1UEuOdP0ao.EZLiB5TIFyZxnufNEF/26Lbi', 2, 3),
('1212', '1212', '1212', '76545432', 'sdv', '123', '$2y$10$OQVsSLY3iJ7lWPNnf1wfXu9J4koBtII7kJbYI9irO4mQdS.dCshPW', 3, 3),
('123', 'hassan', 'hassan', '76545432', 'sdv', '2022', '$2y$10$4remp0f1htl2A2gKETaGYOdNyeosYnAjc6vQEkx1H1.NyaVstGPOu', 2, 2),
('1234', 'abc', 'def', '76545432', 'cs', '2019', '$2y$10$7K2u0/7Npjyq8dw823UoRugt0DruK.ZR64j.Q0s/9Qm8XoRXLKMCq', 2, 2),
('12345678', 'Syed', 'Zohaib', '0309767843', 'CS', 'www.zohaibhassan043@gmail.com', '123', 3, 3),
('321', '123', '123', '123', '123', '123', '$2y$10$xK1GC1xUhygs3fRBGumSe.JhxaYPhQ5ZZWetgHJ/8KaUO91WEbllC', 4, 4),
('3211', '123', '123', '12', '12', '12', '$2y$10$TGWM/RXz0WPOqvqU.uk.OeQjxj7N6v3YbIwceUFOqldt9/LNORuS2', NULL, NULL),
('44556', 'IFRAH', 'JAVAID', '076865464', 'CS', '4', '$2y$10$MrvwZanwQbPn5fSmnHpkse9SnTi19LN8fwkN7BW69oZ6vBvlOZzkq', NULL, NULL);

--Table for Application
DROP TABLE IF EXISTS Application;

CREATE TABLE Application (
  Application_id varchar(255) primary key ,
  Application_status int DEFAULT NULL,
  Room_No int DEFAULT NULL,
  Message varchar(255) DEFAULT NULL,
 Hostel_id int FOREIGN KEY  REFERENCES hostel(Hostel_id),
 Student_id varchar(255) FOREIGN KEY  REFERENCES student(student_id),
)


INSERT INTO application (Application_id, Application_status, Room_No, Message) 
VALUES
(1, '',  0, 'I am a handicapped, so I would like to have a room at ground floor '),
(2, '123', 2, 'i want to join hostle A'),
(3, '1205', 3, 'want'),
(4, '1234', 2, 'A'),
(5, '321',  5, 'D'),
(6, '3211',  0, ''),
(7, '1212',  3, ''),
(8, '12345678', 3, 'C'),
(9, '44556',  NULL, 'IFRAH');

Select * from application;